# youtube_player_helper
Firefox plugin for doing stuff to help with https://thenamlessguy.github.io/youtube_player/

It adds a clickable icon to your Firefox instance.
When clicked on while the current tab is a youtube playlist, it will convert the playlist into a youtube_playlist playlist.
When clicked on a youtube_player site, it will allow you to slice the current playlist.
